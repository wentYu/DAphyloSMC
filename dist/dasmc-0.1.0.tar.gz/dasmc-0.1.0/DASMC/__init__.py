# DASMC - [module description]
# Copyright (C) 2026 Your Name / Your Institution
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

__version__ = "0.1.0"

from . import p4
import sys
# import pkgutil
# import importlib
#
#
# for mod_name in list(sys.modules.keys()):
#     if mod_name == 'p4' or mod_name.startswith('p4.'):
#         del sys.modules[mod_name]
#
# importlib.invalidate_caches()
#
# sys.modules['p4'] = p4
#
# for module_info in pkgutil.walk_packages(p4.__path__, 'p4.'):
#     try:
#         mod = importlib.import_module(module_info.name)
#         sys.modules[module_info.name] = mod
#     except ImportError:
#         continue